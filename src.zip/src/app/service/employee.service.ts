import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees ;
  getEmployeeService(){
    this.employees = [
      {id:101,name:"Manasa Boddu",salary:12897,city:"Chennai",age:22,gender:2,
      dob:new Date("August 23 , 1998"),pan:"PVBM456D",mobile:"5671239870"},
      {id:102,name:"Manasi kumar",salary:13467,city:"pune",age:23,gender:2,
      dob:new Date("April 24 , 1997"),pan:"PVCG256G",mobile:"8458904321"},
      {id:103,name:"MadhuLatha ",salary:12337,city:"Maharashtra",age:22,gender:2,
      dob:new Date("May 23 , 1998"),pan:"CGBM932H",mobile:"7895463456"},
      {id:104,name:"Vijay ",salary:13678,city:"Kerala",age:24,gender:1,
      dob:new Date("June 23 , 1996"),pan:"HGFA234K",mobile:"7653429870"},
      {id:105,name:"Rajesh",salary:12667,city:"Chennai",age:22,gender:1,
      dob:new Date("January 14 , 1998"),pan:"CXOP531I",mobile:"7213905467"},
      {id:106,name:"Lalitha",salary:13456,city:"Pune",age:23,gender:3,
      dob:new Date("September 23 , 1997"),pan:"JFVQ540L",mobile:"7341293891"},
      {id:107,name:"Naina",salary:13218,city:"Chennai",age:24,gender:3,
      dob:new Date("November 13 , 1996"),pan:"LKTF401S",mobile:"9876432709"},
    ];
  }

  constructor() { }
}
