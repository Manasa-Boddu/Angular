import { RedDirective } from './red.directive';

describe('RedDirective', () => {
  it('should create an instance', () => {
    const directive = new RedDirective();
    expect(directive).toBeTruthy();
  });
});
