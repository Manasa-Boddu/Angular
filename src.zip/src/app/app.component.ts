import { Component } from '@angular/core';
import {HttpclientService  } from './services/httpclient.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my Angular Application'
//course =["Java" ,"C#","springboot","Deveps" ]
//trainer:string = "Manasa Boddu"
//name = {"fname":"Manasa","lname":"Boddu"}
//col = "red"
//show()
//{
  //alert("hi"+this.trainer)
//}
//hello(){
  //alert("hi good morning")
//}
public persondata = [];
   constructor(private myservice: HttpclientService) {}
   ngOnInit() {
      this.myservice.getData().subscribe((data) => {
         this.persondata = Array.from(Object.keys(data), k=>data[k]);
         console.log(this.persondata);
      });
   }

}
