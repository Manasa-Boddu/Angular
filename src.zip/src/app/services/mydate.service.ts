import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MydateService {

  constructor() { }
  showTodayDate():any{
    let ndate = new Date();
    return ndate ; 
  }
}
