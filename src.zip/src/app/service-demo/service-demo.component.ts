import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../service/employee.service'
@Component({
  selector: 'app-service-demo',
  templateUrl: './service-demo.component.html',
  styleUrls: ['./service-demo.component.css'],
providers:[EmployeeService]
})
export class ServiceDemoComponent implements OnInit {
employees:any[] ;
message = "";
id:number ;
name:string ;
salary :number ;
city:string;
model:any={};
model2:any={};
emps:any;
myValue:any ;
  constructor(es:EmployeeService) {
    console.log("employee service component is started")
  this.emps = es.getEmployeeService() ; 
  }
  getAllEmployee()
  {
    console.log("In get all employees")
    return this.emps ;
  }
deleteEmployeeById(id:number)
{
  console.log('delete'+id)
  this.emps.splice(id , 1)
}


updateEmployee()
{
  console.log("inside update") ;
  let k = this.myValue ;
  for(let i = 0 ;i <this.emps.length ; i++)
  {
    if(i == k)
    {
      this.emps[i] = this.model2 ;
      this.model2 = {}
    }
  }
}
addEmployee(){
  console.log("in add") ;
  this.emps.push(this.model) ;
  this.model = {} ;
}
editEmployeeById(k:number){
  this.model2.id = this.emps[k].id ;
  this.model2.name = this.emps[k].name ;
  this.model2.salary = this.emps[k].salary ;
  this.model2.city = this.emps[k].city;
  this.myValue = k;
}
  ngOnInit(): void {
  }

}
