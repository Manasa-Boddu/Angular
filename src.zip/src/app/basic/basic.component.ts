import { Component, OnInit } from '@angular/core';
import {MydateService} from '../services/mydate.service';
@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css'],
  providers:[MydateService]
})
export class BasicComponent implements OnInit {
title:string ;
todaydate;
  constructor(private mydate:MydateService) {
    console.log("initializing")
    this.title = "Welcome To Angular"
    this.todaydate = this.mydate.showTodayDate();

   }

  ngOnInit(): void {
    console.log("inside ngOnInit")
    
  }

}
