import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
name:string = "Manasa Boddu";
cmp = "Atos Syntel private ltd";
salary = 12345.765498123;
tdate = new Date();
loc:string;
emp = {"fname":"Manasa","lname":"Boddu"}
  constructor() { 
    console.log("pipe initializing")
    this.loc ="chennai"
  }

  ngOnInit(): void {
  }

}
