import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule} from '@angular/forms';
import { BasicComponent } from './basic/basic.component';
import { RedDirective } from './directives/red.directive';
import { DirectivedemoComponent } from './directivedemo/directivedemo.component';
import { PipesComponent } from './pipes/pipes.component';
import { TemplateComponent } from './template/template.component';
import { PipesdemoComponent } from './pipesdemo/pipesdemo.component';
import { GenderPipe } from './gender.pipe';
import { HttpClientModule } from '@angular/common/http';
import { ServiceDemoComponent } from './service-demo/service-demo.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';


@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    RedDirective,
    DirectivedemoComponent,
    PipesComponent,
    TemplateComponent,
    PipesdemoComponent,
    GenderPipe,
    ServiceDemoComponent,
    ParentComponent,
    ChildComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
