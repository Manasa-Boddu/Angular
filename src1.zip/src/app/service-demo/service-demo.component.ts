import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../service/employee.service'
@Component({
  selector: 'app-service-demo',
  templateUrl: './service-demo.component.html',
  styleUrls: ['./service-demo.component.css'],
providers:[EmployeeService]
})
export class ServiceDemoComponent implements OnInit {
  empdata:any[];
  empdata1:any={};
  empdata2:any={};
  constructor(private es:EmployeeService) {
    console.log("employee service component is started")
    this.empdata=this.es.getAllEmployeeService();
  }
  ngOnInit(): void {
  }
  getAllEmployees():any[]{
    console.log("in get all employees")
           return this.empdata;
  }
  getEmployeeById(id:number){
    console.log(id); 
  } 
    deleteEmployeeById(id:number){
      console.log('delete'+id)
  this.empdata.splice(id, 1);  //index,length
   //this.getAllEmployees();
    
    }
    myValue;
    editEmployeeById(k:number){
       this.empdata2.id=this.empdata[k].id;
     this.empdata2.userId=this.empdata[k].userId;
this.empdata2.firstName=this.empdata[k].firstName;
    this.empdata2.lastName=this.empdata[k].lastName;
    this.empdata2.preferredFullname=this.empdata[k].preferredFullName;
    this.empdata2.employeeCode=this.empdata[k].employeeCode;
this.empdata2.region=this.empdata[k].region;
   this.empdata2.phoneNumber=this.empdata[k].phoneNumber;
   this.empdata2.emailAddress=this.empdata[k].emailAddress;
    this.myValue=k;
    }
    updateEmployee()
                {
                  console.log("in update");
                  let k=this.myValue;
                  for(let i=0;i<this.empdata.length;i++)
                  {
              if (i==k)
            {
              this.empdata[i]=this.empdata2;
              this.empdata2={}
      
            }
                  }
      
                }
                addEmployee(){
                  console.log("in add")
                // this.employee={this.emps,name:"Ayansh Mane",salary:32342.44554,city:"Solapur"};
                // this.emps.push(new Employee(this.id,this.name,this.salary,this.city));
                this.empdata.push(this.empdata1)
                this.empdata1={};
         
                }
               

        ngOnDestroy() {
          console.log("EmployeeAppComponent destroyed...")
        }
}


