import { Component, OnInit, Input, Output , EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
childMsg = "Child Message"
@Input()
virus = ""
@Input()
parentmsg = ""
@Output()
childChanged = new EventEmitter<string>()
sendMessageToParent()
{
  this.childChanged.emit(this.childMsg);
  console.log("In sendmessagetoparent") ;
}  
constructor() { }

  ngOnInit(): void {
  }

}
