import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  length:any;
  push:any;
employee=[
  
  {
    "id":1,
    "userId":"21",
    "jobTitleName":"Developer",
    "firstName":"Manasa",
    "lastName":"Boddu",
    "preferredFullName":"Manasa Boddu",
    "employeeCode":"A1",
    "region":"AC1",
    "phoneNumber":"9848567590",
    "emailAddress":"manasa@gmail.com"
    },
    {
      "id":2,
    "userId":"22",
    "jobTitleName":"Associate",
    "firstName":"karthik",
    "lastName":"kumar",
    "preferredFullName":"karthi kumar",
    "employeeCode":"A2",
    "region":"AC2",
    "phoneNumber":"7654983290",
    "emailAddress":"karthik@gmail.com"
    },
    {
      "id":3,
    "userId":"24",
    "jobTitleName":"Trainee",
    "firstName":"Anuradha",
    "lastName":"kumari",
    "preferredFullName":"Anu",
    "employeeCode":"A3",
    "region":"S2",
    "phoneNumber":"658902347",
    "emailAddress":"anu@gmail.com"
    }
    ]

  constructor() {
    console.log("Employee data")
   }
   getAllEmployeeService(): any{
    return this.employee;
    
  }
    
}
