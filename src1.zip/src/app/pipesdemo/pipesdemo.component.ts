import { Component, OnInit } from '@angular/core';
import {Observable , Subscriber} from 'rxjs';

@Component({
  selector: 'app-pipesdemo',
  templateUrl: './pipesdemo.component.html',
  styleUrls: ['./pipesdemo.component.css']
})
export class PipesdemoComponent implements OnInit {
title = "Welcome To Pipes";
time=new Observable<string>((s:Subscriber<string>)=>{
  setInterval(()=>{s.next(new Date().toLocaleString());},1000);
})
  rows = 5 ;
temp:number = 0 ;
employees = [
  {id:104,name:"Manasa Boddu",salary:12897,city:"Chennai",age:22,gender:2,
  dob:new Date("August 23 , 1998"),pan:"PVBM456D",mobile:"5671239870"},
  {id:102,name:"Manasi kumar",salary:13467,city:"pune",age:23,gender:2,
  dob:new Date("April 24 , 1997"),pan:"PVCG256G",mobile:"8458904321"},
  {id:101,name:"MadhuLatha ",salary:12337,city:"Maharashtra",age:22,gender:2,
  dob:new Date("May 23 , 1998"),pan:"CGBM932H",mobile:"7895463456"},
  {id:103,name:"Vijay ",salary:13678,city:"Kerala",age:24,gender:1,
  dob:new Date("June 23 , 1996"),pan:"HGFA234K",mobile:"7653429870"},
  {id:107,name:"Rajesh",salary:12667,city:"Chennai",age:22,gender:1,
  dob:new Date("January 14 , 1998"),pan:"CXOP531I",mobile:"7213905467"},
  {id:106,name:"Lalitha",salary:13456,city:"Pune",age:23,gender:3,
  dob:new Date("September 23 , 1997"),pan:"JFVQ540L",mobile:"7341293891"},
  {id:105,name:"Naina",salary:13218,city:"Chennai",age:24,gender:3,
  dob:new Date("November 13 , 1996"),pan:"LKTF401S",mobile:"9876432709"},
];
sort(){
  for (let i = 0; i < this.employees.length; i++) {     
    for (let j = i+1; j < this.employees.length; j++) {     
       if(this.employees[i].id > this.employees[j].id) {    
           this.temp = this.employees[i].id;    
           this.employees[i].id = this.employees[j].id;    
           this.employees[j].id = this.temp;    
}
}
  }
}
 
constructor() { }

  ngOnInit(): void {
  }

}
